// @ts-ignore
import packageJSON from '../package.json';
import fs from 'fs-extra'
import path from 'path'
import scanPath from './scanPath';
import { NotChangeEnums } from './NotChangeEnums';


// const fs = require('fs-extra');
// const path = require('path');
// const scanPath = require('./scanPath');

let resPath = path.join(Editor.Project.path, '/assets');
class fc {
    /** 大批量替换字体 */
    static batchChangePrefabs(fontUuid:string, isAddFont:boolean) {
        let resourcesPath = path.join(resPath, './');
        let fileDirs = scanPath.findChildDirNames(resourcesPath, null);
        let dirNames:any[] = [];
        fileDirs.forEach((element) => {
            let files = scanPath.findFiles(path.join(element.path, element.name), /\.prefab$|\.scene$/, true);
            if (files && files.length > 0) {
                dirNames.push(element.name);
            }
        
            files.forEach((file) => {
                const isCan = NotChangeEnums.some(el=>{
                  return el+ ".prefab" === file.name  || el+ ".scene" === file.name 
                })
                console.log(file.name,isCan);
                if (!isCan) {
                    let dir = path.join(file.path, file.name);
                    let prefab = JSON.parse(fs.readFileSync(dir) as any);
                    this.changePrefab(dir, prefab, fontUuid, isAddFont);
                }
            })
        });
      
        for (let i = 0; i < dirNames.length; i++) {
           Editor.Message.request("asset-db",'refresh-asset','db://assets/' + dirNames[i]);
        }
      
        // let str = Editor.T(`${PACKAGE_NAME}.addFont`);
        // if (!isAddFont) {
        //   str = Editor.T(`${PACKAGE_NAME}.removeFont`);
        // }
      
        // Editor.success(str + Editor.T(`${PACKAGE_NAME}.finish`));
    }
    /** 大批量替换文字节点尺寸 */
    static batchChangeSize() {
        console.log("开始查询文件");
        
        let resourcesPath = path.join(resPath, './');
        let fileDirs = scanPath.findChildDirNames(resourcesPath, null);
        let dirNames:any[] = [];
        fileDirs.forEach((element) => {
            let files = scanPath.findFiles(path.join(element.path, element.name), /\.prefab$|\.scene$/, true);
            if (files && files.length > 0) {
                dirNames.push(element.name);
            }
            files.forEach((file) => {
                let dir = path.join(file.path, file.name);
                let prefab = JSON.parse(fs.readFileSync(dir) as any);
                this.changePrefabLableSize(dir, prefab);
            })
        });
      
        for (let i = 0; i < dirNames.length; i++) {
           Editor.Message.request("asset-db",'refresh-asset','db://assets/' + dirNames[i]);
        }
    }
    static changePrefab(fileName:string, data:any, fontUUid:string, isAdd:boolean) {
        for (let i = 0; i < data.length; i++) {
      
          //如果是系统字 则font设为改为 目标字体
          if (data[i].__type__ == 'cc.Label') {
            if (data[i]._isSystemFontUsed) {//系统字
              if (isAdd) {
                data[i]._isSystemFontUsed = false;
                if (!data[i]._font) {
                  let object = {
                    "__uuid__": fontUUid
                  }
                  data[i]._font = object;
                }
              } else {
                if (data[i]._font) {
                  data[i]._font = null;
                }
              }
            } else {//非系统字
      
              if (!isAdd) {
                if (data[i]._font) {
                  let object = data[i]._font;
      
                  if (object['__uuid__'] == fontUUid) {
                    data[i]._font = null;
                    data[i]._isSystemFontUsed = true;
                  }
                }
              } else if (data[i]._font) {//非系统字   有字体  就不处理
      
              } else {//非系统字 但是没有字体
                if (!data[i]._font) {
                  let object = {
                    "__uuid__": fontUUid
                  }
                  data[i]._font = object;
                }
              }
            }
          }
      
          if (data[i].__type__ == 'cc.RichText') {
            if (data[i]._isSystemFontUsed) {//系统字
              if (isAdd) {//加字体
                data[i]._isSystemFontUsed = false;
                if (!data[i]._font) {
                  let object = {
                    "__uuid__": fontUUid
                  }
                  data[i]._font = object;
                }
              } else {
                if (data[i]._font) {
                  data[i]._font = null;
                }
              }
            } else {//非系统字  
              if (!isAdd) {//移除字体
      
                if (data[i]._font) {
                  let object = data[i]._font;
      
                  if (object['__uuid__'] == fontUUid) {
                    data[i]._font = null;
                    data[i]._isSystemFontUsed = true;
                  }
                }
              } else if (data[i]._font) {//非系统字   有字体  就不处理
      
              } else {//非系统字 但是没有字体
                if (!data[i]._font) {
                  let object = {
                    "__uuid__": fontUUid
                  }
                  data[i]._font = object;
                }
              }
            }
          }
        }
      
        fs.writeFileSync(fileName, JSON.stringify(data, null, 2), { encoding: 'utf-8' });
    }
    static changePrefabLableSize(fileName:string, data:any) {
        const needSize = 24;
        let ids:{id:number, lableData:any}[] = []
        for (let i = 0; i < data.length; i++) {
          //寻找有label且字体尺寸小于标准尺寸的节点
          if (data[i].__type__ == 'cc.Label' || data[i].__type__ == 'cc.RichText') {
              if(data[i]._fontSize < needSize){
                ids.push({id:data[i].node.__id__, lableData:data[i]})
              }
          }
        }
        if (ids.length > 0) {
          console.log("修改文字预制体：-------------------", data[0]._name);
          
          for (let i = 0; i < ids.length; i++) {
            const v = ids[i];
              console.log("文字节点", data[v.id]._name);
              data[v.id]._lscale.x = data[v.id]._lscale.y = (v.lableData._fontSize / needSize).toFixed(2); 
              v.lableData._fontSize = 24;
          }
        }
        fs.writeFileSync(fileName, JSON.stringify(data, null, 2), { encoding: 'utf-8' });
    }
}
/**
 * @en 
 * @zh 为扩展的主进程的注册方法
 */
export const methods: { [key: string]: (...any: any) => any } = {
    openPanel() {
        Editor.Panel.open(packageJSON.name);
    },
    addFont(data){
        let jsonData = data[0];
        let fontUuid = jsonData.fontUuid;
        fc.batchChangePrefabs(fontUuid, true)
    },
    changeLabelSize(){
        fc.batchChangeSize()
    },
};

/**
 * @en Hooks triggered after extension loading is complete
 * @zh 扩展加载完成后触发的钩子
 */
export function load() { }

/**
 * @en Hooks triggered after extension uninstallation is complete
 * @zh 扩展卸载完成后触发的钩子
 */
export function unload() { }
