import { readFileSync } from 'fs-extra';
import { join } from 'path';
const edit = require("../../../other/editor2D")
import packageJSON from '../../../package.json';
import { log } from 'console';
/**
 * @zh 如果希望兼容 3.3 之前的版本可以使用下方的代码
 * @en You can add the code below if you want compatibility with versions prior to 3.3
 */
// Editor.Panel.define = Editor.Panel.define || function(options: any) { return options }
module.exports = Editor.Panel.define({
    listeners: {
        show() { console.log('show'); },
        hide() { console.log('hide'); },
    },
    template: readFileSync(join(__dirname, '../../../static/template/default/index.html'), 'utf-8'),
    style: readFileSync(join(__dirname, '../../../static/style/default/index.css'), 'utf-8'),
    $: {
        app: '#app',
        uuidNum: '#uuidNum',
        addFont: '#addFont',
        changeSize: '#changeSize',
    },
    methods: {
        // hello() {
        //     if (this.$.app) {
        //         this.$.app.innerHTML = '字体替换工具';
        //         console.log('[cocos-panel-html.default]: hello');
        //     }
        // },
    },
    ready() {
        if (this.$.app) {
            this.$.app.innerHTML = '字体替换工具';
        }
        console.log("打开文字扩展");
        this.$.addFont?.addEventListener("click", async ()=>{
            const uuid = (this.$.uuidNum as HTMLInputElement)?.value;
            let fontUuid = uuid as string;
            const url = await Editor.Message.request("asset-db", "query-url", fontUuid)
            if (!url) {
                console.log(packageJSON.name)
                return;
            }
            let jsonData = {
                'fontUuid': fontUuid
            }
            Editor.Message.broadcast(`add-font`, [jsonData]);
        })
        
        this.$.changeSize?.addEventListener("click", async ()=>{
            Editor.Message.broadcast(`change-size`);
        })
    },
    beforeClose() { },
    close() { },
});
