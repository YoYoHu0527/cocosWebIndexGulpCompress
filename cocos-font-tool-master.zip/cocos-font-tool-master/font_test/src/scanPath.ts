import fs from 'fs-extra'
import path from 'path'

export default class scanPath {
    static scan(pp:any, suffix:any, cb:Function) {
        if (!fs.existsSync(pp)) return;
        let myFiles = fs.readdirSync(pp);
        for (let i in myFiles) {
            let name = myFiles[i];
            let newPp = path.join(pp, name);
            let stat = fs.lstatSync(newPp);

            if (stat.isDirectory()) {
                this.scan(newPp, suffix, cb);
            } else {
                if (name.substring(- suffix.length) == suffix) cb(newPp);
            }
        }
    }
    static findFiles(p:any, tag:any, isNext:any) {
        let files:any[] = [];
        let dir = fs.readdirSync(p);
        dir.forEach((one:any) => {
            let f = path.join(p, one);

            let stat = fs.statSync(f);
            if (stat.isDirectory()) { // 继续循环
                if (isNext) {
                    let ff = this.findFiles(f, tag, isNext)
                    ff.forEach(a => { files.push(a) });
                }
                return;
            }
            if (tag.test(one)) files.push({ path: p, name: one });
        });
        return files;
    }
    
    static findChildDirNames(p:any, tag:any) {
        let files:any[] = [];
        let dir = fs.readdirSync(p);
        dir.forEach(one => {
            let f = path.join(p, one);
            let stat = fs.statSync(f);
            if (stat.isDirectory()) {// 继续循环
                if (tag) {
                    if (tag.test(f)) files.push({ path: p, name: one });
                } else {
                    files.push({ path: p, name: one });
                }
                return;
            }
        });
        return files;

    }
}