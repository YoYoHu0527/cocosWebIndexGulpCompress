/**
 *
 * 不做文字替换的页面名称  
 */
export const NotChangeEnums = [
    "SkillViewItem.prefab",
    "DailyPurchasePage.prefab",
]