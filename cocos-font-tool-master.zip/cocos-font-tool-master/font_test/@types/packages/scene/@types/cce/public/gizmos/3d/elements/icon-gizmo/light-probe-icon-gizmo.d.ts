import IconGizmoBase from './icon-gizmo-base';
export default class LightProbeIconGizmo extends IconGizmoBase {
    disableOnSelected: boolean;
    createController(): void;
}
//# sourceMappingURL=light-probe-icon-gizmo.d.ts.map