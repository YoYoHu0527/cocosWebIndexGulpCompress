import gizmo from './3d/gizmo-manager';
export default gizmo;
//# sourceMappingURL=index.d.ts.map