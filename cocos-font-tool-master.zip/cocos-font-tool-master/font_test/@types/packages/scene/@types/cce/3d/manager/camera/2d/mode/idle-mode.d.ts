import { ModeBase } from './mode-base';
declare class IdleMode extends ModeBase {
    enter(): Promise<void>;
    exit(): Promise<void>;
}
export { IdleMode };
//# sourceMappingURL=idle-mode.d.ts.map