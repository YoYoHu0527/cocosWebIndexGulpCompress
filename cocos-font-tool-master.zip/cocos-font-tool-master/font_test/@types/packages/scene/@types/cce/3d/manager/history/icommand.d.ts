export interface ICommand {
    undo(): Promise<void>;
    redo(): Promise<void>;
}
//# sourceMappingURL=icommand.d.ts.map