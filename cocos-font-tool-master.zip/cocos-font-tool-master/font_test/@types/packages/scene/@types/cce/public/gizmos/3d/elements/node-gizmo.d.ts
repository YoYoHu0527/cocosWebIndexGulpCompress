import Gizmo from './gizmo-base';
declare class NodeGizmo extends Gizmo {
}
export default NodeGizmo;
//# sourceMappingURL=node-gizmo.d.ts.map