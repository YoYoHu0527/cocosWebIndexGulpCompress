import { EventEmitter } from '../../../utils/event-emitter';
declare class EngineUtil extends EventEmitter {
}
export { EngineUtil };
//# sourceMappingURL=engine.d.ts.map