declare class WireframeNode extends cc.Node {
    private _isWireframeNode;
    constructor(name: string);
    get isWireframeNode(): boolean;
}
export default WireframeNode;
//# sourceMappingURL=wireframe.d.ts.map