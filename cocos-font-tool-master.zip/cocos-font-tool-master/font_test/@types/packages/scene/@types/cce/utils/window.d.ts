import type { ISizeLike } from 'cc';
/**
 * 获取引擎主窗口的宽高
 * @returns
 */
export declare function getMainWindowSize(): ISizeLike;
//# sourceMappingURL=window.d.ts.map